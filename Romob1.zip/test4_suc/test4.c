unsigned int T1overflow;
unsigned long T1counts;
unsigned long T1time;
unsigned int Dcntr;
void motor2(unsigned int speed);
void ATD_init(void);
unsigned int ATD_read(void);
//void CCPPWM_init(void);
void motor(unsigned int speed) ;
unsigned int Distance_M(void);
unsigned int Distance;
unsigned int speed;

unsigned int v;





void msDelay(unsigned int msCnt)
{
    unsigned int ms=0;
    unsigned int cc=0;
    for(ms=0;ms<(msCnt);ms++)
    {
      for(cc=0;cc<155;cc++);//1ms
    }
}

void usDelay(unsigned int usCnt)
{
    unsigned int us=0;

    for(us=0;us<usCnt;us++)
    {
      asm NOP;//0.5 uS
      asm NOP;//0.5uS
    }
}
 void interrupt(void){
 if(INTCON&0x04){// will get here every 1ms
    TMR0=248;
    Dcntr++;
    if(Dcntr==500){//after 500 ms
      Dcntr=0;
     ATD_read();
     //cntr++;
    }
  INTCON = INTCON & 0xFB; //clear T0IF
}
 if(PIR1&0x04){//CCP1 interrupt

 PIR1=PIR1&0xFB;
 }
 if(PIR1&0x01){//TMR1 ovwerflow

   T1overflow++;

   PIR1=PIR1&0xFE;
 }

 if(INTCON&0x02){//External Interrupt


   INTCON=INTCON&0xFD;
   }


 }
void main() {
       unsigned int dis=0;

    TRISC=   0b00000000;
     TRISB = 0b00000010;     //declare as output
      TRISD= 0b00000000;
     T1CON = 0x10;

      //CCPPWM_init(void);
     ATD_init(void);                //Initialize Timer Module

      motor2(25);
    while(1){
    v=ATD_read(void);
      speed= (((v>>2)*250)/255);// 0-250
      motor(speed)   ;

      dis = Distance_M()  ;


      while(dis>20){
      //strat and move front
        dis=Distance_M()  ;
        if(dis<=15){break;}
        v=ATD_read(void);
        speed= (((v>>2)*250)/255);// 0-250
        motor(speed)   ;
        motor2(25);
        msDelay(500);

        //move front and check distance
        PORTD=0b00001010;
        msDelay(500);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        msDelay(500);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        msDelay(500);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        msDelay(500);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        v=ATD_read(void);
        speed= (((v>>2)*250)/255);// 0-250
        motor(speed)   ;
        motor2(25);
        msDelay(500);
        dis=Distance_M()  ;
        if(dis<=20){break;}


        //move right and check distance
        PORTD=0b00001001;
        msDelay(250);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        msDelay(250);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        v=ATD_read(void);
        speed= (((v>>2)*250)/255);// 0-250
        motor(speed)   ;
        motor2(25);
        msDelay(250);


        //move front and check distance
        PORTD=0b00001010;
        msDelay(250);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        msDelay(250);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        msDelay(250);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        msDelay(250);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        msDelay(250);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        v=ATD_read(void);
        speed= (((v>>2)*250)/255);// 0-250
        motor(speed)   ;
        motor2(25);
        msDelay(250);

         //move left and check distance
        PORTD=0b00000110;
        delay_ms(250);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        msDelay(250);
        dis=Distance_M()  ;
        if(dis<=20){break;}
        msDelay(250);
        dis=Distance_M()  ;
        if(dis<=20){break;}
         msDelay(250);
      }


      //move right until Distance be more than 20cm
      PORTD=0b00001001;
        v=ATD_read(void);
        speed= (((v>>2)*250)/255);// 0-250
        motor(speed)   ;
        motor2(25);

         msDelay(500);


    }
}


void ATD_init(void){
ADCON0=0x41;//ON, Channel 0, Fosc/16== 500KHz, Dont Go
ADCON1=0xCE;// RA0 Analog, others are Digital, Right Allignment,
}


unsigned int ATD_read(void){
         ADCON0=ADCON0 | 0x04;//GO
         while(ADCON0&0x04);//wait until DONE
         return (ADRESH<<8)|ADRESL;

}

unsigned int Distance_M(void){
T1overflow=0;
    TMR1H=0;
    TMR1L=0;

    PORTB=0x04;//Trigger the ultrasonic sensor (RB2 connected to trigger)
    usDelay(10);//keep trigger for 10uS
    PORTB=0x00;//Remove trigger
    while(!(PORTB&0x02));
    T1CON=0x19;//TMR1 ON,  Fosc/4 (inc 1uS) with 1:2 prescaler (TMR1 overflow after 0xFFFF counts ==65536)==> 65.536ms
    while(PORTB&0x02);
    T1CON=0x18;//TMR1 OFF,  Fosc/4 (inc 1uS) with 1:1 prescaler (TMR1 overflow after 0xFFFF counts ==65536)==> 65.536ms
    T1counts=((TMR1H<<8)|TMR1L)+(T1overflow*65536);
       if(TMR1L>100) PORTC=0xFF;
       T1time=T1counts;//in microseconds
       Distance=((T1time*34)/(1000))/2; //in cm, shift left twice to divide by 2
       //range=high level time(usec)*velocity(340m/sec)/2 >> range=(time*0.034cm/usec)/2
       //time is in usec and distance is in cm so 340m/sec >> 0.034cm/usec
       //divide by 2 since the travelled distance is twice that of the range from the object leaving the sensor then returning when hitting an object)

return Distance;
}

/*void CCPPWM_init(void){ //Configure CCP1 and CCP2 at 2ms period with 50% duty cycle
  T1overflow=0;
    TMR1H=0;
    TMR1L=0;

    PORTB=0x04;//Trigger the ultrasonic sensor (RB2 connected to trigger)
    usDelay(10);//keep trigger for 10uS
    PORTB=0x00;//Remove trigger
    while(!(PORTB&0x02));
    T1CON=0x19;//TMR1 ON,  Fosc/4 (inc 1uS) with 1:2 prescaler (TMR1 overflow after 0xFFFF counts ==65536)==> 65.536ms
    while(PORTB&0x02);
    T1CON=0x18;//TMR1 OFF,  Fosc/4 (inc 1uS) with 1:1 prescaler (TMR1 overflow after 0xFFFF counts ==65536)==> 65.536ms
    T1counts=((TMR1H<<8)|TMR1L)+(T1overflow*65536);
       if(TMR1L>100) PORTC=0xFF;
       T1time=T1counts;//in microseconds
       Distance=((T1time*34)/(1000))/2; //in cm, shift left twice to divide by 2
       //range=high level time(usec)*velocity(340m/sec)/2 >> range=(time*0.034cm/usec)/2
       //time is in usec and distance is in cm so 340m/sec >> 0.034cm/usec
       //divide by 2 since the travelled distance is twice that of the range from the object leaving the sensor then returning when hitting an object)

}*/

void motor(unsigned int speed){
      CCPR2L=speed;
}
void motor2(unsigned int speed){
      CCPR1L=speed;
}