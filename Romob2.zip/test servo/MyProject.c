void ATD_init(void);
unsigned int ATD_read(void);
unsigned int k;
unsigned int angle;
unsigned int Dcntr;
unsigned int Mcntr;
unsigned char cntr;
unsigned char HL;//High Low
unsigned char test;//High Low
void myDelay(unsigned int x);

void interrupt(void){
   if(INTCON&0x02){//External Interrupt
   INTCON=INTCON&0xFD;
   }
   if(INTCON&0x04){// will get here every 1ms
    TMR0=248;
    Mcntr++;
    Dcntr++;
    if(Dcntr==500){//after 500 ms
      Dcntr=0;
    }
  INTCON = INTCON & 0xFB; //clear T0IF
}
 if(PIR1&0x04){//CCP1 interrupt
   if(HL){ //high
     CCPR1H= angle >>8;
     CCPR1L= angle;
     HL=0;//next time low
     CCP1CON=0x09;//next time Falling edge
     TMR1H=0;
     TMR1L=0;
   }
   else{  //low
     CCPR1H= (40000 - angle) >>8;
     CCPR1L= (40000 - angle);
     CCP1CON=0x08; //next time rising edge
     HL=1; //next time High
     TMR1H=0;
     TMR1L=0;
   }
 PIR1=PIR1&0xFB;
 }
 if(PIR1&0x01){//TMR1 ovwerflow
   PIR1=PIR1&0xFE;
 }
 }

void main() {
trisb = 0x06;
TRISC =0x00;
PORTC=0x00;
TRISD=0x00;
PORTD=0x00;
ATD_init();
test=0;
 // Configure RA1 as digital input (button)
    ADCON1 |= 0x04;    // set RA2 digital (AN1 off)
    TRISA |= 0x02;

TMR1H=0;
TMR1L=0;
TMR0=248;
HL=1; //start high
CCP1CON=0x08;//
OPTION_REG = 0x87;//Fosc/4 with 256 prescaler => incremetn every 0.5us*256=128us ==> overflow 8count*128us=1ms to overflow
T1CON=0x01;//TMR1 On Fosc/4 (inc 0.5uS) with 0 prescaler (TMR1 overflow after 0xFFFF counts ==65535)==> 32.767ms
INTCON=0xF0;//enable TMR0 overflow, TMR1 overflow, External interrupts and peripheral interrupts;
PIE1=PIE1|0x04;// Enable CCP1 interrupts
CCPR1H=2000>>8;
CCPR1L=2000;
//angle=1200; //600us initially == 1200*0.5=600
  while(1){
  if ((PORTB & 0x02) == 0) {
            myDelay(20);
            if ((PORTB & 0x02) == 0) {
                test=1; // 0�
                while ((PORTB & 0x02) == 0);
                myDelay(10);
            }
        }
        else if ((PORTB & 0x04) == 0) {
            myDelay(20);
            if ((PORTB & 0x04) == 0) {
                test=0; // 180�
                while ((PORTB & 0x04) == 0);
                myDelay(10);
            }
        }
          angle = (test)? 3500 : 1000;
        /*else {
            // Normal potentiometer control
            k = ATD_read();          // 0..1023
            k = k >> 2;              // scale to 0..255
            angle = 1000 + ((k * 25) / 2.55);
            if (angle > 3500) angle = 3500;
            if (angle < 1000) angle = 1000;
             }
     /* angle=3500;
      delay_ms(2000);
      angle=1200;
      delay_ms(2000); */
  }}

void myDelay(unsigned int x){
     Mcntr=0;
     while(Mcntr<x);
}

void ATD_init(void){
      ADCON0=0x41;//ON, Channel 0, Fosc/16== 500KHz, Dont Go
      ADCON1=0xCE;// RA0 Analog, others are Digital, Right Allignment,
      TRISA=0x01;
}

unsigned int ATD_read(void){
      ADCON0=ADCON0 | 0x04;//GO
      while(ADCON0&0x04);//wait until DONE
      return (ADRESH<<8)|ADRESL;
}